import MetricsListEntry from "./MetricsListEntry.jsx"
function CMMandible() {
    return(<div className="editor-scroll">
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        <MetricsListEntry name = "mandible"/>
        </div>)
}
export default CMMandible