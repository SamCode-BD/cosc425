import MetricsListEntry from "./MetricsListEntry.jsx"
function CMCranium() {
    return(<div className = "editor-scroll">
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        <MetricsListEntry name="cranium"/>
        </div>)
}
export default CMCranium