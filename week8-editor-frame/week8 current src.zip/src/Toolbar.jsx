import ButtonContainer from "./ButtonContainer"

function Toolbar(props) {
    return(
        <div className = "toolbar">
            <ButtonContainer toolbarSubContext={props.toolbarSubContext}/>
        </div>
    )
}
export default Toolbar