import "./EditorWindow.css"
import React, {useState, useContext} from 'react'
import { InventoryContext } from "./EditorContainer";

function InventoryEntry(props) {

    const inventoryContext = useContext(InventoryContext);

    let [buttonActive, setButtonActive] = useState(false);

    const getButton = () => {
        if(buttonActive == true) {
            return(
                <button onClick={() => {inventoryContext.setTaphonomyActive(true);
                                        inventoryContext.setActiveBone(props.name)
                                        inventoryContext.setSubmenuOfActiveBone(props.submenu)}}>Edit</button>
            );
        }
    }

    const getOption = () => {

        if(props.options != null) {

            if(props.options.length == 1) {
                return(<div className = "inventory-options">
                    <select>
                        {props.options.map((item, i) => <option value={item} key={i}>{item}</option>)}
                    </select>
                </div>);
            }

            else if(props.options.length == 2) {
                let lr = (props.submenu != "Vertebrae")?(
                <>
                    <p style ={{gridColumn: "1 / 2", margin: "0"}}>L</p>
                    <p style ={{gridColumn: "2 / 3", margin: "0"}}>R</p>
                </>):(<></>);

                return(<div className = "inventory-options">
                    {lr}
                    {props.options.map((list, i) => 
                    <select key={i} style={{gridRow: "2 / 3"}}>
                        {list.map((item, j) => <option value={item} key={j}>{item}</option>)}
                    </select>)}
            </div>)
            }

        }
        else {
            return(<div>null</div>)
        }
       
    }

    const getInputElements = () => {
        if(props.type == null) {
            return(getBoxes());
        }
        else if(props.type == "option") {
            return(getOption());
        }
    }

    const getBoxes = () => {
        if(props.numBoxes == "1") {
            return (
                <div className = "inventory-checkboxes">
            <p></p>
            <input type="checkbox"/>
            </div>
        );
        }
        else if(props.numBoxes == "2") {
            if(props.submenu != "Vertebrae") {
                return (
                    <div className = "inventory-checkboxes">
                <p>L</p>
                <input type="checkbox"/>
                <p>R</p>
                <input type="checkbox"/>
                </div>
                );
            }
            else {
                return (
                    <div className = "inventory-checkboxes">
                <p></p>
                <input type="checkbox"/>
                <p></p>
                <input type="checkbox"/>
                </div>
                );
            }
            
        }
        else if(props.numBoxes == "3") {
            return (
                <div className = "inventory-checkboxes">
            <p>L</p>
            <input type="checkbox"/>
            <p>Body</p>
            <input type="checkbox"/>
            <p>R</p>
            <input type="checkbox"/>
            </div>
        );
        }
    }

    return(
    <div className="inventory-entry" onMouseEnter={() => {setButtonActive(true)}}
                                     onMouseLeave={() => {setButtonActive(false)}}>
        <p>{props.name}</p>
        {getInputElements()}
        {getButton()}
    </div>)
}

export default InventoryEntry