import Toolbar from "./Toolbar.jsx"
import EditorContainer from "./EditorContainer.jsx"
import "./Right.css"
import "./Toolbar.css"
import React, {useState} from 'react'

function Right() {
    let toolbarSubContext = useState("main");
    return(<div className = "right">
        <Toolbar toolbarSubContext={toolbarSubContext}/>
        <EditorContainer toolbarSubContext={toolbarSubContext}/>
    </div>);
}
export default Right