import Left from "./Left.jsx"
import Right from "./Right.jsx"
import "./App.css"

function App() {

  return (
    <div className = "container">
      <Left/>
      <Right/>
    </div>
  )
}

export default App
