import "./EditorWindow.css"
import { InventoryContext } from "./EditorContainer.jsx";
import React, {useContext} from 'react'

function Taphonomy(props) {

    const inventoryContext = useContext(InventoryContext);

    const getSubtitle = () => {
        let str = "";
        let activeSubmenu = inventoryContext.submenuOfActiveBone[0].toUpperCase() + inventoryContext.submenuOfActiveBone.slice(1);
        str += activeSubmenu + " - " + inventoryContext.activeBone;
        return(str);
    }

    if(inventoryContext.taphonomyActive) {
        return(
            <div className = "taphonomy">
                <div className = "taphonomy-title">
                    Taphonomy: {getSubtitle()}
                </div>
                <div className = "condition-exposure">
                    <p className = "condition-exposure-item">Bone Condition: </p>
                    <input className = "condition-exposure-item condition-input"/>
                    <button className = "condition-exposure-item help-button">?</button>
                    <p className = "condition-exposure-item" >Surface Exposure: </p>
                    <input className = "condition-exposure-item" type="checkbox"/>
                </div>
                <div className = "taphonomy-context-buttons">
                    <button>Bone Color</button>
                    <button>Staining</button>
                    <button>Surface Damage</button>
                    <button>Adherent Materials</button>
                    <button>Modifications</button>
                </div>
                <div className = "taphonomy-contents">
                    contents
                </div>
            </div>);
    }
    else {
        return(<></>);
    }
    
}
export default Taphonomy